
#import <Foundation/Foundation.h>
#import "CPTheme.h"

@interface CPXYTheme : CPTheme {

}

@end
