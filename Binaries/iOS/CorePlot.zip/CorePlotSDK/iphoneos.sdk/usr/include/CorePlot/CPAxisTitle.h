
#import <Foundation/Foundation.h>
#import "CPAxisLabel.h"


@interface CPAxisTitle : CPAxisLabel {

}

@end
